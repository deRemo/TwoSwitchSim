#include<stdio.h>
#include<math.h>
#include"lcgrand.h"
#include<stdlib.h>

int main(int argc, char* argv[]){
	if(argc < 3){
		printf("Usage: ./program #numbers stream");
		return -1;
	}
	
	int n = atoi(argv[1]);
	int stream = atoi(argv[2]);
	FILE* out = fopen("gen.out", "w");

	for(int i=0; i<n; i++){
		fprintf(out, "%f\n", lcgrand(stream));
	}

	fclose(out);

	return 0;
}
