#!/usr/bin/python3

import math
import numpy as np
import os
import matplotlib.pyplot as plt

N = 100000
STREAM = 3

plt.rc('xtick', labelsize=18) 
plt.rc('ytick', labelsize=18)

fun = {} #used to store the pdf, cdf and inv. cdf on the distribution to be plotted

def plots(fun, nums, x, title, bins):
	#inverse transform
	nums = list(map(fun["inv_cdf"], nums))
	pdf_y = list(map(fun["pdf"], x))
	cdf_y = list(map(fun["cdf"], x))
	
	#pdf
	counts, bins, _ = plt.hist(nums, bins=bins, density=True, color="antiquewhite", edgecolor="black")
	if title == "pareto":
		plt.yscale('log', nonposy='clip')
	plt.plot(x, pdf_y, color="red", linewidth = 2, linestyle="--")
	plt.savefig(f"./images/{title}_pdf.pdf")
	plt.show()

	#cdf
	plt.plot(x, cdf_y, color="red", linewidth = 2, linestyle="--")
	plt.hist(nums, bins=bins, density=True, cumulative=True, color="antiquewhite", edgecolor="black")
	plt.savefig(f"./images/{title}_cdf.pdf")
	plt.show()

#Execute
os.system(f"./gen {N} {STREAM}")

#Retrieve rand nums
#ASSUMPTION: for every value v in nums: 0 < v < 1
nums = None
with open("./gen.out", "r") as f:
	lines = f.read().splitlines()
	nums = [float(l) for l in lines]

#Convert to numpy array
nums = np.array(nums)

####################################################################

#Unif [0,1)
a = 0.01
b = 1.0
unif_pdf = lambda x : 1/(b-a) if a <= x < b else 0
unif_cdf = lambda x : (x-a)/(b-a) if a <= x < b else 0 if x<a else 1
unif_inv_cdf = lambda u : a + u * (b - a)
fun["pdf"] = unif_pdf
fun["cdf"] = unif_cdf
fun["inv_cdf"] = unif_inv_cdf

x = np.linspace(a,b,N)
plots(fun, nums.copy(), x, "unif1", 40)

#Unif [4,10]
a = 4
b = 10

x = np.linspace(a,b,N)
plots(fun, nums.copy(), x, "unif2", 40)


#expon (beta = (1/lambda) = 2)
beta = 2

#Assumption: x >= 0 
expon_pdf = lambda x : (1/beta) * math.exp(-x/beta)
expon_cdf = lambda x : 1 - math.exp(-x/beta)
expon_inv_cdf = lambda u : -np.log(u) * beta #using u instead of 1-u, since 0 < u < 1
fun["pdf"] = expon_pdf
fun["cdf"] = expon_cdf
fun["inv_cdf"] = expon_inv_cdf

x = np.linspace(0.01, 25, N)
plots(fun, nums.copy(), x, "expon", 80)


#pareto (alfa = 4, kappa = 2)
alfa = 4
kappa = 2

pareto_pdf = lambda x : (alfa * (kappa ** alfa )) / (x ** (alfa + 1)) if x >= kappa else 0 
pareto_cdf = lambda x : 1 - ((kappa/x) ** alfa) if x >= kappa else 0
pareto_inv_cdf = lambda u : kappa  / (u ** (1/alfa)) #using u instead of 1-u, since 0 < u < 1
fun["pdf"] = pareto_pdf
fun["cdf"] = pareto_cdf
fun["inv_cdf"] = pareto_inv_cdf

x = np.linspace(start=0, stop=40, num=N)
plots(fun, nums.copy(), x, "pareto", 80)
