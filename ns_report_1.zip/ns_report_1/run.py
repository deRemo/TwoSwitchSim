#!/usr/bin/python3

import numpy as np
import os
import matplotlib.pyplot as plt

N = [10, 1000000]
SEEDS = [1,2,3,4,5]

TRANSMISSION_RATE = 1000000 #(in bits/s)
PKT_SIZE = 1500 * 8 #(in bits)

SERVICE_TIME = PKT_SIZE / TRANSMISSION_RATE #0.012
INTERARRIVAL_TIMES = [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2] 

queue_delays = None #qd
system_delays = None #sd

#Combine all parameters and execute simulation
for n in N:
	#Plots setup
	qd_fig, qd_ax = plt.subplots()
	sd_fig, sd_ax = plt.subplots()
	axs = [qd_ax, sd_ax]
	figs = [qd_fig, sd_fig]

	for ax,label in zip(axs, ["Queue delay", "System delay"]):
		ax.set_xlabel("Arrival rate (secs)", fontsize=18)
		ax.set_ylabel(f"Avg. {label} (secs)", fontsize=18)
		ax.set_title(f"N={n}", fontsize=20)

	for seed in SEEDS:
		stats = {} #collected stats for a single seed

		for interarrival_time in INTERARRIVAL_TIMES:
			#Prepare mm1.in for run
			config = f"{interarrival_time} {SERVICE_TIME} {n} {seed}"
			print(f"Running config: {config}")

			with open("./mm1.in", "w") as f:
				f.write(config)

			#execute mm1 (remember to compile it!)
			os.system("./mm1")
			
			#Retrieve queue delay and system delay data from mm1.out
			with open("./mm1.out", "r") as f:
				lines = f.read().splitlines()

				queue_delay_line = list(filter(lambda line : "delay" in line and "queue" in line, lines))[0]
				system_delay_line = list(filter(lambda line : "delay" in line and "system" in line, lines))[0]

				#No stats found => overflow
				if len(queue_delay_line) == 0 or len(system_delay_line) == 0:
					print("System Overflow")
					exit(-1)
				else:
					queue_delay = float(queue_delay_line.split(' ')[-2])
					system_delay = float(system_delay_line.split(' ')[-2])

			#Store stats in function of the arrival rate
			print(queue_delay, system_delay)
			if queue_delay is not None and system_delay is not None:
				stats[1/interarrival_time] = (queue_delay, system_delay)
			else:
				print("Error while retrieving stats")
				exit(-1)
			
		#Plot
		queue_delays = [val[0] for val in stats.values()]
		system_delays = [val[1] for val in stats.values()]

		qd_ax.plot(stats.keys(), queue_delays, label=f"seed {seed}")
		sd_ax.plot(stats.keys(), system_delays, label=f"seed {seed}")

	#Generate legend
	for ax in axs:
		ax.legend()

	#Save fig
	for fig,label in zip(figs,["QD", "SD"]):	
		fig.tight_layout()
		fig.savefig(f"./images/n{n}_{label}.pdf")

print("Check the plot in images/ folder")
