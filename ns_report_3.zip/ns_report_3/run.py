#!/usr/bin/python3

import numpy as np
import os
import matplotlib.pyplot as plt
import scipy.stats as st

N = [10, 1000000]
SEEDS = [1,2,3,4,5,6,7,8,9,10]

TRANSMISSION_RATE = 1000000 #(in bits/s)
PKT_SIZE = 1500 * 8 #(in bits)

SERVICE_TIME = PKT_SIZE / TRANSMISSION_RATE #0.012
INTERARRIVAL_TIMES = [0.0121, 0.0122, 0.0123, 0.0124, 0.0125, 0.0126, 0.0127, 0.0128, 0.0129, 0.013] #[0.014, 0.016, 0.018, 0.020, 0.022, 0.024, 0.028, 0.030, 0.032, 0.034] 
x = list(map(lambda x:1/x, INTERARRIVAL_TIMES)) #because we plot in function of the arrival rate

def confidence_interval(values, alpha, distr):
	assert 0 < alpha < 1, "CHECK THAT 0 < alpha < 1"
	assert distr == "t" or distr == "norm", "WRONG distr name"

	if distr == "t":
		lb,ub = st.t.interval(alpha=alpha, df=len(values)-1, loc=np.mean(values), scale=st.sem(values, nan_policy='omit')) #where  sem(a) == a.std(ddof=1) / np.sqrt(len(a))
	else:
		lb,ub = st.norm.interval(alpha=alpha, loc=np.mean(values), scale=st.sem(values, nan_policy='omit'))

	return lb,ub 

#Combine all parameters and execute simulation
for n in N:
	#gathered stats
	#x_stats[seed] = [x_delay1, .. x_delayN] for each interarrival rate (=1/interarrival_time)
	qd_stats = {} 
	sd_stats = {}

	for seed in SEEDS:
		qd_stats[seed] = []
		sd_stats[seed] = []
		for interarrival_time in INTERARRIVAL_TIMES:
			#Prepare mm1.in for run
			config = f"{interarrival_time} {SERVICE_TIME} {n} {seed}"
			print(f"Running config: {config}")

			with open("./mm1.in", "w") as f:
				f.write(config)

			#execute mm1 (remember to compile it!)
			os.system("./mm1")
			
			#Retrieve queue delay and system delay data from mm1.out
			with open("./mm1.out", "r") as f:
				lines = f.read().splitlines()

				queue_delay_line = list(filter(lambda line : "delay" in line and "queue" in line, lines))[0]
				system_delay_line = list(filter(lambda line : "delay" in line and "system" in line, lines))[0]

				#No stats found => overflow
				if len(queue_delay_line) == 0 or len(system_delay_line) == 0:
					print("System Overflow")
					exit(-1)
				else:
					queue_delay = float(queue_delay_line.split(' ')[-2])
					system_delay = float(system_delay_line.split(' ')[-2])

			#Store stats in function of the arrival rate
			print(queue_delay, system_delay)
			if queue_delay is not None and system_delay is not None:
				qd_stats[seed].append(queue_delay)
				sd_stats[seed].append(system_delay)
			else:
				print("Error while retrieving stats")
				exit(-1)

	#Compute confidence intervals for each arrival rate
	for stats,fig_label,ylabel in zip([qd_stats, sd_stats], ["QD", "SD"], ["Queue", "System"]):
		stats = np.array(list(stats.values())) #convert to numpy array
		
		for seeds_to_consider in [3, 6, len(SEEDS)]:
			fig, ax = plt.subplots()

			#Plots setup
			stats_slice = stats[0:seeds_to_consider,:]
			print(stats_slice)

			conf99 = np.apply_along_axis(lambda col: confidence_interval(col, 0.99, "t"), axis=1, arr=stats_slice.T)
			conf90 = np.apply_along_axis(lambda col: confidence_interval(col, 0.90, "t"), axis=1, arr=stats_slice.T)
			avg_stats = np.average(stats_slice, axis=0)

			ax.plot(x, avg_stats, color="darkgray", linestyle="--")
			ax.fill_between(x, conf99.T[0,:], conf99.T[1,:], alpha=.1, color="darkgray")
			ax.fill_between(x, conf90.T[0,:], conf90.T[1,:], alpha=.3, color="darkgray")

			ax.set_xlabel("Arrival rate (pkt/mins)", fontsize=18)
			ax.set_ylabel(f"Avg. {ylabel} delay (mins)", fontsize=18)
			ax.set_title(f"N={n}, samples={stats_slice.shape[0]}", fontsize=20)

			fig.tight_layout()
			fig.savefig(f"./images/n{n}_samples{seeds_to_consider}_{fig_label}_conf.pdf")		

print("Check the plot in images/ folder")
